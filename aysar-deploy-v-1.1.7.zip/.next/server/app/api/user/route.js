var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user/route.js")
R.c("server/chunks/[root-of-the-server]__096wavc._.js")
R.c("server/chunks/_0m5._k5._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_user_route_actions_0xlxkdv.js")
R.m(666840)
module.exports=R.m(666840).exports
