var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/password/route.js")
R.c("server/chunks/[root-of-the-server]__0617d21._.js")
R.c("server/chunks/085c_bcryptjs_index_0h-kfb9.js")
R.c("server/chunks/_0m5._k5._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_user_password_route_actions_0shmr0d.js")
R.m(552889)
module.exports=R.m(552889).exports
