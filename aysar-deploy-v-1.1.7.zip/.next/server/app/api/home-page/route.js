var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/home-page/route.js")
R.c("server/chunks/[root-of-the-server]__0h01_xp._.js")
R.c("server/chunks/_0_vg3sx._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/app_lib_shared-types_ts_0.dkyfp._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_home-page_route_actions_03k.ap..js")
R.m(138281)
module.exports=R.m(138281).exports
