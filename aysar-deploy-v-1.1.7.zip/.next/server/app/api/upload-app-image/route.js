var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload-app-image/route.js")
R.c("server/chunks/[root-of-the-server]__0k1wolv._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_upload-app-image_route_actions_1095l1_.js")
R.m(148059)
module.exports=R.m(148059).exports
