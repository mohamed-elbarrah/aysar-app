var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload-bento-icon/route.js")
R.c("server/chunks/[root-of-the-server]__0n0l2_h._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_upload-bento-icon_route_actions_0.5eipa.js")
R.m(824731)
module.exports=R.m(824731).exports
