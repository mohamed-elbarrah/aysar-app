var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/upload-logo/route.js")
R.c("server/chunks/[root-of-the-server]__02d05h4._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_upload-logo_route_actions_0by82pr.js")
R.m(917179)
module.exports=R.m(917179).exports
