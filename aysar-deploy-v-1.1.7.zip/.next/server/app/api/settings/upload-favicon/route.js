var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/upload-favicon/route.js")
R.c("server/chunks/[root-of-the-server]__0mkpu3-._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_upload-favicon_route_actions_12cst4s.js")
R.m(230338)
module.exports=R.m(230338).exports
