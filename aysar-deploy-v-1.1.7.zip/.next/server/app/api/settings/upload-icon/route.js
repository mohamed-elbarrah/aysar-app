var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/upload-icon/route.js")
R.c("server/chunks/[root-of-the-server]__0l4.1-3._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_upload-icon_route_actions_09..1pm.js")
R.m(174903)
module.exports=R.m(174903).exports
