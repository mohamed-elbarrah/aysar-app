var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/policies/[type]/route.js")
R.c("server/chunks/[root-of-the-server]__0mvfwhf._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/app_lib_shared-types_ts_0.dkyfp._.js")
R.c("server/chunks/_next-internal_server_app_api_policies_[type]_route_actions_02kz8gf.js")
R.m(566235)
module.exports=R.m(566235).exports
