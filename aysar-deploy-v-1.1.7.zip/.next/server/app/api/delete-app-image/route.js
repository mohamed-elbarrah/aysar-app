var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/delete-app-image/route.js")
R.c("server/chunks/[root-of-the-server]__000.lqo._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_delete-app-image_route_actions_00x-x_i.js")
R.m(228319)
module.exports=R.m(228319).exports
