var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact-page/route.js")
R.c("server/chunks/[root-of-the-server]__01~w2na._.js")
R.c("server/chunks/_0_vg3sx._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/app_lib_shared-types_ts_0.dkyfp._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_contact-page_route_actions_0dezgjo.js")
R.m(773225)
module.exports=R.m(773225).exports
