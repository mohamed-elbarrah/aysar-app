var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__11jbq~w._.js")
R.c("server/chunks/_0m5._k5._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_0q2btsk.js")
R.m(770449)
module.exports=R.m(770449).exports
