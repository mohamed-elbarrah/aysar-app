var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/plans-page/route.js")
R.c("server/chunks/[root-of-the-server]__07a8gi4._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/app_lib_shared-types_ts_0.dkyfp._.js")
R.c("server/chunks/_next-internal_server_app_api_plans-page_route_actions_0zrtvxv.js")
R.m(18182)
module.exports=R.m(18182).exports
