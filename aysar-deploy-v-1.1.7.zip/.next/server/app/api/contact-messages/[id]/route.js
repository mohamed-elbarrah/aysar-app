var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/contact-messages/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__100nb8-._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/_next-internal_server_app_api_contact-messages_[id]_route_actions_00no7qu.js")
R.m(38810)
module.exports=R.m(38810).exports
