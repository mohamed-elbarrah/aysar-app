var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact-messages/route.js")
R.c("server/chunks/[root-of-the-server]__0nzgx7.._.js")
R.c("server/chunks/[root-of-the-server]__0iga-fk._.js")
R.c("server/chunks/app_lib_shared-types_ts_0.dkyfp._.js")
R.c("server/chunks/_0jy2-km._.js")
R.c("server/chunks/_next-internal_server_app_api_contact-messages_route_actions_0ozaw5l.js")
R.m(505767)
module.exports=R.m(505767).exports
