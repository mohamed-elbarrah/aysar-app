var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__09f43db._.js")
R.c("server/chunks/ssr/0z~i_next_dist_esm_build_templates_app-page_0xvzu58.js")
R.c("server/chunks/ssr/[root-of-the-server]__0j-7ihp._.js")
R.c("server/chunks/ssr/0z~i_next_dist_0u-8flw._.js")
R.c("server/chunks/ssr/0z~i_next_dist_client_components_builtin_global-error_0_.8paw.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0k77kol.js")
R.m(843936)
module.exports=R.m(843936).exports
