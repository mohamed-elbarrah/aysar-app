1:"$Sreact.fragment"
2:I[5233,["/_next/static/chunks/06~2in0lajtdw.js","/_next/static/chunks/0puvap3tne1vy.js"],"default"]
3:I[73632,["/_next/static/chunks/06~2in0lajtdw.js","/_next/static/chunks/0puvap3tne1vy.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"TtlAJFyobFxIedGQ4RkBY"}
