1:"$Sreact.fragment"
2:I[83775,["/_next/static/chunks/06~2in0lajtdw.js","/_next/static/chunks/0puvap3tne1vy.js"],"ViewportBoundary"]
3:I[83775,["/_next/static/chunks/06~2in0lajtdw.js","/_next/static/chunks/0puvap3tne1vy.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"TtlAJFyobFxIedGQ4RkBY"}
