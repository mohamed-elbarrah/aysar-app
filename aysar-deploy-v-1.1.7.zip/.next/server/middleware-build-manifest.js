globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/TtlAJFyobFxIedGQ4RkBY/_buildManifest.js",
    "static/TtlAJFyobFxIedGQ4RkBY/_ssgManifest.js",
    "static/TtlAJFyobFxIedGQ4RkBY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ytkoqyhmtij5.js",
    "static/chunks/0hirent~9i71j.js",
    "static/chunks/0s-eobk.~-lpg.js",
    "static/chunks/02hsnp8e~kwm..js",
    "static/chunks/0y3fi2m24vmea.js",
    "static/chunks/turbopack-17_8dnv059r3e.js"
  ]
};
