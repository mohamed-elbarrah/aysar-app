module.exports=[995262,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contact-messages_route_actions_0ozaw5l.js.map