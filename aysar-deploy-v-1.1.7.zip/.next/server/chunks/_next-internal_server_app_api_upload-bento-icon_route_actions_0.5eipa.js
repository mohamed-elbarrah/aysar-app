module.exports=[447151,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload-bento-icon_route_actions_0.5eipa.js.map