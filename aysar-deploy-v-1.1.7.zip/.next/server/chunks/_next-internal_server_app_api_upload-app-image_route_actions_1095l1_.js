module.exports=[857650,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload-app-image_route_actions_1095l1_.js.map