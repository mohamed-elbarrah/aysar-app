module.exports=[460777,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_terms-of-use_page_actions_0geul.l.js.map