module.exports=[179110,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_dashboard_policies_page_actions_08o1x.g.js.map