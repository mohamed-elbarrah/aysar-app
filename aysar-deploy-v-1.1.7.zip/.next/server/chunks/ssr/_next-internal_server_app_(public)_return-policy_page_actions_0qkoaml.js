module.exports=[85078,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_return-policy_page_actions_0qkoaml.js.map