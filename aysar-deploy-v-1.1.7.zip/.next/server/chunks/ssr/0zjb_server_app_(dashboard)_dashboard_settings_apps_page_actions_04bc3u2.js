module.exports=[825360,(a,b,c)=>{}];

//# sourceMappingURL=0zjb_server_app_%28dashboard%29_dashboard_settings_apps_page_actions_04bc3u2.js.map