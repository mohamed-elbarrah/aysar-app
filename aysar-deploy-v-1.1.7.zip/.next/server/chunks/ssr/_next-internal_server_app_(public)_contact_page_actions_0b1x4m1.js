module.exports=[26767,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_contact_page_actions_0b1x4m1.js.map