module.exports=[496243,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_dashboard_plans-page_page_actions_0t2ho5h.js.map