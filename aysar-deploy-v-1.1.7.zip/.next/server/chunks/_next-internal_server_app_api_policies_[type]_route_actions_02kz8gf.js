module.exports=[620923,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_policies_%5Btype%5D_route_actions_02kz8gf.js.map