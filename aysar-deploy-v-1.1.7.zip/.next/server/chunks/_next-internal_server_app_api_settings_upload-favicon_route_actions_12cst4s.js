module.exports=[939134,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_upload-favicon_route_actions_12cst4s.js.map