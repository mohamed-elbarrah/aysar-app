module.exports=[167690,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_upload-logo_route_actions_0by82pr.js.map