module.exports=[660611,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contact-messages_%5Bid%5D_route_actions_00no7qu.js.map