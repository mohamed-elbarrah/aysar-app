module.exports=[80043,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_delete-app-image_route_actions_00x-x_i.js.map