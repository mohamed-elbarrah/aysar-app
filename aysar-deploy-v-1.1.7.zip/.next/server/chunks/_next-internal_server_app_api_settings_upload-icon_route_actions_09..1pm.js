module.exports=[364373,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_upload-icon_route_actions_09..1pm.js.map