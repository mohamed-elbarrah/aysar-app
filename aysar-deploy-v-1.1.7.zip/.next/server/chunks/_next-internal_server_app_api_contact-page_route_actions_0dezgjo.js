module.exports=[412171,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contact-page_route_actions_0dezgjo.js.map