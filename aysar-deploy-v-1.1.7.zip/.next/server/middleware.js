var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0uufhoi._.js")
R.c("server/chunks/[root-of-the-server]__0wr3.48._.js")
R.m(982553)
module.exports=R.m(982553).exports
