"use client";

import { useEffect, useRef, useState } from "react";

function createScriptElement(oldScript: HTMLScriptElement): HTMLScriptElement {
  const el = document.createElement("script");
  for (const attr of oldScript.attributes) {
    el.setAttribute(attr.name, attr.value);
  }
  el.textContent = oldScript.textContent;
  return el;
}

function LoadingSkeleton() {
  return (
    <div className="animate-pulse space-y-5">
      <div className="h-10 bg-[#e8edf5] rounded-lg w-full" />
      <div className="h-10 bg-[#e8edf5] rounded-lg w-full" />
      <div className="h-10 bg-[#e8edf5] rounded-lg w-3/4" />
      <div className="h-24 bg-[#e8edf5] rounded-lg w-full" />
      <div className="h-12 bg-gradient-to-r from-[#0c2954] to-[#2d2e83] rounded-lg w-full opacity-30" />
    </div>
  );
}

function ErrorFallback() {
  return (
    <div className="text-center py-8 px-4">
      <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-[#fef3c7] flex items-center justify-center">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="#f59e0b" strokeWidth="2" />
          <path d="M12 8v4M12 16h.01" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <h3 className="text-[18px] font-bold text-[#0c2954] mb-2">
        عذراً، حدث خطأ في تحميل النموذج
      </h3>
      <p className="text-[14px] text-[#6b7a94] leading-[1.7] mb-6">
        يرجى التواصل معنا عبر إحدى الطرق التالية:
      </p>
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <a
          href="http://wa.me/966125101107"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#25D366] text-white font-medium rounded-xl hover:bg-[#20bd5a] transition-colors"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
          </svg>
          تواصل عبر واتساب
        </a>
        <a
          href="mailto:info@aysar.sa"
          className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#2d2e83] text-white font-medium rounded-xl hover:bg-[#252570] transition-colors"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="20" height="16" x="2" y="4" rx="2" />
            <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
          </svg>
          راسلنا عبر البريد
        </a>
      </div>
    </div>
  );
}

type Phase = "loading" | "loaded" | "error";

function hasRenderedContent(container: HTMLDivElement): boolean {
  if (container.children.length === 0) return false;

  for (const child of container.children) {
    const tag = child.tagName.toLowerCase();
    if (tag === "div" && child.firstElementChild) return true;
    if (tag === "iframe") return true;
    if (tag === "form") return true;
    if (tag === "input" || tag === "select" || tag === "textarea") return true;
    if (tag === "button") return true;
  }

  return Boolean(container.innerText && container.innerText.trim().length > 20);
}

export function ThirdPartyForm({ scriptHtml }: { scriptHtml: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<Phase>("loading");
  const prevScriptRef = useRef(scriptHtml);

  useEffect(() => {
    if (!containerRef.current) return;

    prevScriptRef.current = scriptHtml;

    if (!scriptHtml) return;

    const container = containerRef.current;
    container.innerHTML = "";
    setPhase("loading");

    let resolved = false;
    let fallbackTimeout: ReturnType<typeof setTimeout>;

    const resolve = () => {
      if (resolved) return;
      resolved = true;
      observer.disconnect();
      clearTimeout(fallbackTimeout);
      setPhase("loaded");
    };

    const observer = new MutationObserver(() => {
      if (hasRenderedContent(container)) {
        resolve();
      }
    });

    observer.observe(container, { childList: true, subtree: true, characterData: true });

    const temp = document.createElement("div");
    temp.innerHTML = scriptHtml;
    while (temp.firstChild) {
      container.appendChild(temp.firstChild);
    }

    const scripts = Array.from(container.querySelectorAll("script"));
    for (const oldScript of scripts) {
      try {
        const newScript = createScriptElement(oldScript);
        oldScript.parentNode?.replaceChild(newScript, oldScript);
      } catch {
        // skip failing scripts
      }
    }

    if (hasRenderedContent(container)) {
      resolve();
    }

    fallbackTimeout = setTimeout(() => {
      if (hasRenderedContent(container)) {
        setPhase("loaded");
      } else {
        setPhase("error");
      }
      observer.disconnect();
    }, 12000);

    return () => {
      observer.disconnect();
      clearTimeout(fallbackTimeout);
      container.innerHTML = "";
    };
  }, [scriptHtml]);

  return (
    <div className="relative">
      {phase === "loading" && <LoadingSkeleton />}

      {phase === "error" && <ErrorFallback />}

      <div
        ref={containerRef}
        className="transition-opacity duration-300"
        style={{
          opacity: phase === "loaded" ? 1 : 0,
          height: phase === "loaded" ? "auto" : 0,
          overflow: phase === "loaded" ? "visible" : "hidden",
        }}
      />
    </div>
  );
}
